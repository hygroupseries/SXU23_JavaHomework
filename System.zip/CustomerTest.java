
/**
 * CustomerTest类，程序的入口点。
 */
public class CustomerTest {
    /**
     * main方法，创建CustomerView对象并启动系统。
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        CustomerView customerView = new CustomerView();
        customerView.start();
    }
}
