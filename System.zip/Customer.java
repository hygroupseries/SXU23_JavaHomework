

/**
 * Customer类，一个标准的JavaBean，用于表示客户信息。
 */
public class Customer {
    private String roomId;
    private String name;
    private int age;
    private String gender;
    private String idNumber;

    /**
     * 默认构造函数
     */
    public Customer() {
    }

    /**
     * 带有所有参数的构造函数
     * @param roomId 房间号
     * @param name 姓名
     * @param age 年龄
     * @param gender 性别
     * @param idNumber 身份证号
     */
    public Customer(String roomId, String name, int age, String gender, String idNumber) {
        this.roomId = roomId;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.idNumber = idNumber;
    }

    // --- Getter and Setter methods ---

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    /**
     * 重写toString方法，方便打印客户信息
     * @return 格式化后的客户信息字符串
     */
    @Override
    public String toString() {
        return roomId + "\t\t" + name + "\t\t" + age + "\t\t" + gender + "\t\t" + idNumber;
    }
}

