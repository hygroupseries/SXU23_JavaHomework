

import java.util.Scanner;

/**
 * CustomerView类，负责显示界面和处理用户交互。
 */
public class CustomerView {
    // 创建一个最大容量为10的客户数组
    private Customer[] customers = new Customer[10];
    // 用于接收用户输入的Scanner对象
    private Scanner scanner = new Scanner(System.in);
    // 记录当前客户数量
    private int count = 0;

    /**
     * 启动方法，显示主菜单并循环等待用户操作。
     */
    public void start() {
        while (true) {
            System.out.println("\n------商务酒店管理系统------");
            System.out.println("1. 添加顾客信息");
            System.out.println("2. 修改顾客信息");
            System.out.println("3. 删除顾客信息");
            System.out.println("4. 查看顾客信息");
            System.out.println("5. 退出系统");
            System.out.print("请选择(1-5): ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // 消费换行符

            switch (choice) {
                case 1:
                    addCustomer();
                    break;
                case 2:
                    updateCustomer();
                    break;
                case 3:
                    deleteCustomer();
                    break;
                case 4:
                    findAllCustomer();
                    break;
                case 5:
                    System.out.println("酒店期待你的下次到来!");
                    return; // 退出循环和方法
                default:
                    System.out.println("选择错误，请重新输入！");
            }
        }
    }

    /**
     * 添加新的顾客信息。
     */
    private void addCustomer() {
        if (count >= customers.length) {
            System.out.println("房间已满，无法添加新顾客！");
            return;
        }

        System.out.println("请输入房间号:");
        String roomId = scanner.nextLine();
        System.out.println("请输入顾客姓名:");
        String name = scanner.nextLine();
        System.out.println("请输入顾客年龄:");
        int age = scanner.nextInt();
        scanner.nextLine(); // 消费换行符
        System.out.println("请输入顾客性别:");
        String gender = scanner.nextLine();
        System.out.println("请输入顾客身份证号:");
        String idNumber = scanner.nextLine();

        Customer newCustomer = new Customer(roomId, name, age, gender, idNumber);
        customers[count] = newCustomer;
        count++;
        System.out.println("添加顾客信息成功!!");
    }

    /**
     * 查询并显示所有顾客信息。
     */
    private void findAllCustomer() {
        if (count == 0) {
            System.out.println("尊敬的顾客你好, 本店目前所有房间都空着, 没有顾客信息!");
            return;
        }

        System.out.println("房间号\t\t顾客姓名\t\t顾客年龄\t\t顾客性别\t\t顾客身份证号");
        for (int i = 0; i < count; i++) {
            System.out.println(customers[i]);
        }
    }

    /**
     * 根据房间号修改顾客信息。
     */
    private void updateCustomer() {
        System.out.println("请输入要修改的顾客的房间号:");
        String roomId = scanner.nextLine();

        int index = ArrayUtils.findIndexByRoomId(customers, roomId, count);

        if (index == -1) {
            System.out.println("未找到该房间号的顾客信息！");
            return;
        }

        System.out.println("请输入修改后的顾客姓名:");
        String name = scanner.nextLine();
        System.out.println("请输入修改后的顾客年龄:");
        int age = scanner.nextInt();
        scanner.nextLine(); // 消费换行符
        System.out.println("请输入修改后的顾客性别:");
        String gender = scanner.nextLine();
        System.out.println("请输入修改后的顾客身份证号:");
        String idNumber = scanner.nextLine();

        customers[index].setName(name);
        customers[index].setAge(age);
        customers[index].setGender(gender);
        customers[index].setIdNumber(idNumber);

        System.out.println("修改顾客信息成功!");
    }

    /**
     * 根据房间号删除顾客信息。
     */
    private void deleteCustomer() {
        System.out.println("请输入要删除的顾客的房间号:");
        String roomId = scanner.nextLine();

        int index = ArrayUtils.findIndexByRoomId(customers, roomId, count);

        if (index == -1) {
            System.out.println("未找到该房间号的顾客信息！");
            return;
        }

        // 将删除点之后的元素前移一位
        for (int i = index; i < count - 1; i++) {
            customers[i] = customers[i + 1];
        }
        // 将最后一个有效元素置为null，并减少计数
        customers[count - 1] = null;
        count--;

        System.out.println("删除顾客信息成功!");
    }
}
