
/**
 * ArrayUtils类，提供数组操作的静态方法。
 */
public class ArrayUtils {

    /**
     * 根据房间ID在Customer数组中查找客户的索引。
     * @param customers 客户数组
     * @param roomId 要查找的房间ID
     * @param count 当前数组中的有效客户数量
     * @return 如果找到，返回客户在数组中的索引；否则返回-1。
     */
    public static int findIndexByRoomId(Customer[] customers, String roomId, int count) {
        for (int i = 0; i < count; i++) {
            if (customers[i] != null && customers[i].getRoomId().equals(roomId)) {
                return i;
            }
        }
        return -1; // 未找到
    }
}
